package com.example.cmp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmpApplicationTests {

	@Test
	void contextLoads() {
	}

}
